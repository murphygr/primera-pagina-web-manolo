<?php

// Users data
$imSettings['access']['webregistrations_gid'] = 'z3gtvz37';
$imSettings['access']['users'] = array(
	'admin' => array(
		'groups' => array('m92157n4'),
		'id' => 'm92157n4',
		'name' => 'Admin',
		'password' => '0a77a748',
		'email' => '',
		'page' => 'index.html'
	),
	'nuevousuario' => array(
		'groups' => array('13fd42wl'),
		'id' => '13fd42wl',
		'name' => 'Nuevousuario',
		'password' => '9fri3sj0',
		'email' => '',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('m92157n4');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php