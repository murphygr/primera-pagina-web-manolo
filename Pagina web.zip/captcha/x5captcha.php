<?php
include("../res/x5engine.php");
$nameList = array("sle","esn","nkj","gns","7vp","8u6","av2","y5r","4hx","2xs");
$charList = array("4","L","E","8","K","U","5","P","X","6");
$cpt = new X5Captcha($nameList, $charList);
//Check Captcha
if ($_GET["action"] == "check")
	echo $cpt->check($_GET["code"], $_GET["ans"]);
//Show Captcha chars
else if ($_GET["action"] == "show")
	echo $cpt->show($_GET['code']);
// End of file x5captcha.php
